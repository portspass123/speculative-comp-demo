# Speculative Computation — predictive resonance demo

**Short summary**  
A compact, reproducible demo illustrating how phase-locking (predictive resonance) increases inter-trial phase coherence (ITPC) in synthetic signals. This repository contains a runnable script, figures, a Jupyter notebook walkthrough, and outreach guidance. Conceptual credit is given to *Sophia Antipolis* (Sophia).

## Files
- `spec_comp_demo.py` : runnable script (python3) — already included.
- `speculative_comp_demo.ipynb` : explanatory Jupyter notebook with embedded figures.
- `README.md` : this file.
- `LICENSE` : MIT license with attribution to Sophia Antipolis.
- `outreach.txt` : institutions list and suggested entry points.
- `*.png` : figures produced by the demo.
- `summary.json` : numeric outputs from the demo.

## Quick start
1. Install dependencies:
```
pip install numpy scipy matplotlib nbformat
```
2. Run the demo script:
```
python3 spec_comp_demo.py
```
3. To explore the notebook, open `speculative_comp_demo.ipynb` in Jupyter or nteract. The notebook reproduces the simulation and shows the same plots and metrics.

## Citation & attribution
If you reuse or extend this code, please acknowledge the conceptual framing credited to *Sophia Antipolis* and this demo's author when appropriate.

## License
This repository is distributed under the MIT License. See `LICENSE` for full text.
