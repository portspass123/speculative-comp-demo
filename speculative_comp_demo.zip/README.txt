Speculative Computation / Predictive Resonance Demo
Files:
- spec_comp_demo.py : runnable script
- time_domain_avg.png, psd.png, itpc_timecourse.png, itpc_bar.png : figures
- summary.json : metrics summary
Run: python3 spec_comp_demo.py
