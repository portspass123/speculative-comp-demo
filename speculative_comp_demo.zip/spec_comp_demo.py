#!/usr/bin/env python3
# spec_comp_demo.py
# Reproduces the simulation & simple analyses for speculative computation / predictive resonance demo.
import numpy as np
from scipy.signal import hilbert, welch
import matplotlib.pyplot as plt

# parameters (same as in notebook)
fs = 200
duration = 2.0
t = np.linspace(0, duration, int(fs*duration), endpoint=False)
n_trials = 120
target_freq = 10.0
noise_level = 1.0

# generate trials
signal_clean = np.sin(2*np.pi*target_freq*t)
predictable = np.array([signal_clean + noise_level*np.random.randn(len(t)) for _ in range(n_trials)])
randoms = np.array([np.sin(2*np.pi*target_freq*t + np.random.uniform(0,2*np.pi)) + noise_level*np.random.randn(len(t)) for _ in range(n_trials)])

# compute ITPC helper
def compute_itpc(trials, freq):
    analytic_phases = []
    for tr in trials:
        complex_mixed = tr * np.exp(-1j * 2*np.pi*freq*t)
        hz = hilbert(np.real(complex_mixed))
        phase = np.angle(hz)
        analytic_phases.append(phase)
    analytic_phases = np.array(analytic_phases)
    itpc_time = np.abs(np.mean(np.exp(1j*analytic_phases), axis=0))
    return np.mean(itpc_time)

itpc_pred = compute_itpc(predictable, target_freq)
itpc_rand = compute_itpc(randoms, target_freq)
print("ITPC predictable:", itpc_pred)
print("ITPC random:", itpc_rand)
